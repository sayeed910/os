#!/bin/bash
make
rm -f *.o
./search
